
# reading csv
import pandas as pd

data = pd.read_csv("Original.csv")
length1 = len(data)

# drop duplicate values - is it deleting all duplicates? leave 1
# change to just IR number duplicates
data.drop_duplicates(keep=False, inplace=True)
length2 = len(data)

print(data)

# drop by status if not relevant
statuses = ['Planned (Long-term)', 'For Long-term Considerati', 'Under Review', 'Accepted', 'Need More Info']
data = data[data['Status'].isin(statuses)]
length3 = len(data)

# testing - show difference in rows
print("Lines in orginal csv: " + str(length1) + 
    "\n Lines after removing duplicates: " + str(length2) +
    "\n Lines after filtering status: " + str(length3))

# sort descending by votes
data.sort_values(["Votes"], axis=0, ascending=[False], inplace=True)

# top 50 requests
data.head(50).to_csv('Top50.csv')
print("Top 50 Influence Requests of this quarter successfully generated.")

# compare current status of top 50 to last quarter
# created copy of Top50 and changed status of 3 requests to test checking for differences
Top50 = pd.read_csv("Top50.csv")
prevTop50 = pd.read_csv("PrevTop50.csv")
# diff = data.compare(prevTop50, align_axis = 0)
#print(diff)
merged = Top50.merge(prevTop50,how='left', left_on=['Influence ID','Title','Coach'], right_on=['Influence ID','Title','Coach'])
# currently merges all current Top50 and PrevTop50 rows. 
# how do we show only those requests that changed status since prevTop50.
# try: df = pd.merge(df,df2[['Key_Column','Target_Column']],on='Key_Column', how='left')
merged.to_csv('Merged.csv')
